CREATE PROCEDURE sp_select_nofilter()
  BEGIN
	select * from imooc_goddess;
END;

