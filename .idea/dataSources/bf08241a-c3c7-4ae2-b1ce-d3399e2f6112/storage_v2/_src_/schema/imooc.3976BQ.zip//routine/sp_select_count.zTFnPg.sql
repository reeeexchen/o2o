CREATE PROCEDURE sp_select_count(OUT count INT(10))
  BEGIN
	select count(*) into count from imooc_goddess;
END;

