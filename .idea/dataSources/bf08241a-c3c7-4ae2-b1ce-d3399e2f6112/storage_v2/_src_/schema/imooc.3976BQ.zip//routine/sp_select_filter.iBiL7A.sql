CREATE PROCEDURE sp_select_filter(IN sp_name VARCHAR(20))
  BEGIN
	if sp_name is null or sp_name = '' then
		select * from imooc_goddess;
	else
		if length(sp_name) = 11 and substring(sp_name,1,1) = 1 then
			select * from imooc_goddess where mobile = sp_name;
		else
			select * from imooc_goddess where user_name like concat('%',sp_name,'%');
		end if;
	end if;    
END;

